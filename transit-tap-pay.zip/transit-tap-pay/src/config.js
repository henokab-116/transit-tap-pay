const path = require('path');
const crypto = require('crypto');

try { process.loadEnvFile(path.join(__dirname, '..', '.env')); } catch { /* no .env file – fine */ }

const env = process.env;
const PROD = env.NODE_ENV === 'production';

let JWT_SECRET = env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32 || /^replace_me/.test(JWT_SECRET)) {
  if (PROD) {
    console.error('FATAL: set JWT_SECRET (32+ random chars) in .env');
    process.exit(1);
  }
  JWT_SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('[warn] JWT_SECRET missing/weak: using a temporary secret (everyone is logged out on restart).');
}

const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);

module.exports = {
  PROD,
  JWT_SECRET,
  PORT: num(env.PORT, 3000),
  DEMO_MODE: env.DEMO_MODE === 'true',
  TRUST_PROXY: env.TRUST_PROXY === 'true',
  WELCOME_BONUS_ETB: num(env.WELCOME_BONUS_ETB, 100),
  MAX_FARE_ETB: num(env.MAX_FARE_ETB, 100),
  MAX_TOPUP_ETB: num(env.MAX_TOPUP_ETB, 5000),
  MIN_WITHDRAW_ETB: num(env.MIN_WITHDRAW_ETB, 10),
  QR_TTL_MS: 120 * 1000,
  DB_PATH: env.DB_PATH || path.join(__dirname, '..', 'data', 'transit.db')
};
